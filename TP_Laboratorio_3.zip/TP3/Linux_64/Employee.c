#include "Employee.h"
#include "utn.h"
#include "LinkedList.h"
#include <stdio_ext.h>
#include <stdlib.h>
#include <string.h>


Employee* Employee_new()
{
    Employee* this;
    this=malloc(sizeof(Employee));
    return this;
}

void Employee_delete(Employee* this)
{
    free(this);
}

Employee* Employee_newConParametros(char* id,char* nombre,char* horasTrabajadas,char* sueldo)
{
    Employee* this;
    this=Employee_new();
    int validId;
    int validHorasTrabajadas;
    int validSueldo;

    if(
     isValidInt(id,4) &&
     isValidNombre(nombre,64) &&
     isValidInt(horasTrabajadas,4) &&
     isValidInt(sueldo,4))
    {
        validId = atoi(id);
        validHorasTrabajadas = atoi(horasTrabajadas);
        validSueldo = atoi(sueldo);

        if(
        !Employee_setId(this,validId)&&
        !Employee_setNombre(this,nombre)&&
        !Employee_setHorasTrabajadas(this,validHorasTrabajadas)&&
        !Employee_setSueldo(this,validSueldo))
        {
            return this;
        }
    }

    Employee_delete(this);
    return NULL;
}

int Employee_setId(Employee* this,int id)
{
    int retorno=-1;
    static int proximoId=-1;

    if(this!=NULL && id==-1)
    {
        proximoId++;
        this->id=proximoId;
        retorno=0;
    }
    else if(id>proximoId)
    {
        proximoId=id;
        this->id=proximoId;
        retorno=0;
    }
    return retorno;
}

int Employee_getId(Employee* this,int* id)
{
    int retorno=-1;
    if(this!=NULL)
    {
        *id=this->id;
        retorno=0;
    }
    return retorno;
}

int Employee_setNombre(Employee* this,char* nombre)
{
    int retorno=-1;
    if(this!=NULL && nombre!=NULL)
    {
        strcpy(this->nombre,nombre);
        retorno=0;
    }
    return retorno;
}

int Employee_getNombre(Employee* this,char* nombre)
{
    int retorno=-1;
    if(this!=NULL && nombre!=NULL)
    {
        strcpy(nombre,this->nombre);
        retorno=0;
    }
    return retorno;
}

int Employee_setHorasTrabajadas(Employee* this,int horasTrabajadas)
{
    int retorno=-1;
    if(this!=NULL)
    {
        this->horasTrabajadas=horasTrabajadas;
        retorno=0;
    }
    return retorno;
}

int Employee_getHorasTrabajadas(Employee* this,int* horasTrabajadas)
{
    int retorno=-1;
    if(this!=NULL)
    {
        *horasTrabajadas=this->horasTrabajadas;
        retorno=0;
    }
    return retorno;
}

int Employee_setSueldo(Employee* this,int sueldo)
{
    int retorno=-1;
    if(this!=NULL)
    {
        this->sueldo=sueldo;
        retorno=0;
    }
    return retorno;
}

int Employee_getSueldo(Employee* this,int* sueldo)
{
    int retorno=-1;
    if(this!=NULL)
    {
        *sueldo=this->sueldo;
        retorno=0;
    }
    return retorno;
}

int Employee_sortNombre(void* this,void* thib)
{
    char nombreA[64];
    char nombreB[64];
    int retorno = 0;

    if(this != NULL && thib != NULL)
    {
        Employee* firstEmployee = this;
        Employee* secondEmployee = thib;

        Employee_getNombre(firstEmployee,nombreA);
        Employee_getNombre(secondEmployee,nombreB);

        if(strcmp(nombreA,nombreB) > 0)
        {
            retorno = 1;
        }
        else if(strcmp(nombreA,nombreB) < 0)
        {
            retorno = -1;
        }
    }
    return retorno;
}

int Employee_sortId(void* thisA,void* thisB)
{
    int idA;
    int idB;
    int retorno = 0;

    if(thisA != NULL && thisB != NULL)
    {
        Employee_getId(thisA, &idA);
        Employee_getId(thisB, &idB);
        if( idA > idB)
        {
            retorno = 1;
        }
        else if(idA < idB)
        {
            retorno = -1;
        }
    }
    return retorno;
}

/** brief    Se utiliza esta funcion para obtener un nuevo id
*           declarando una variable static para el id y suma 1 al anterior
* \return devuelve un id vacio
*/
int getNextId(LinkedList* pArrayListEmployee)
{
    static int lastId = -1;
    int i;
    int id;
    Employee * auxEmployee;
    if(pArrayListEmployee != NULL)
    {
        ll_sort(pArrayListEmployee,Employee_sortId,1);
        for (i = 1; i<= ll_len(pArrayListEmployee); i++)
        {
            if(i == ll_len(pArrayListEmployee))
            {
                auxEmployee = ll_get(pArrayListEmployee,i-1);
                Employee_getId(auxEmployee, &id);
                lastId = id + 1;
            }
        }
    }
    return lastId;
}

Employee* Employee_buscarPorId(LinkedList* pArrayListEmployee,int idBuscado)
{
    Employee* empleado = NULL;
    Employee* empleadoAux;
    int i;

    if(pArrayListEmployee != NULL && idBuscado >= 0)
    {
        for(i=0;i<ll_len(pArrayListEmployee);i++)
        {
            empleadoAux = ll_get(pArrayListEmployee,i);
            if(idBuscado == empleadoAux->id)
            {
                empleado = empleadoAux;
            }
        }

    }
    return empleado;
}

int Employee_returnIndexInLinkedList(LinkedList* this,int id)
{
    int returnAux = -1;
    Employee* empleado;
    int i;
    if(this != NULL && id >= 0)
    {
        for(i=0;i<ll_len(this);i++)
        {
            empleado = ll_get(this,i);
            if(empleado->id == id)
            {
                returnAux = i;
                break;
            }
        }
    }
    return returnAux;
}
