#ifndef employee_H_INCLUDED
#define employee_H_INCLUDED
#include "LinkedList.h"
typedef struct
{
    int id;
    char nombre[128];
    int horasTrabajadas;
    int sueldo;
}Employee;


Employee* Employee_new();
void Employee_delete();
Employee* Employee_newConParametros(char* id,char* nombre,char* horasTrabajadas,char* sueldo);

int Employee_setId(Employee* this,int id);
int Employee_getId(Employee* this,int* id);

int Employee_setNombre(Employee* this,char* nombre);
int Employee_getNombre(Employee* this,char* nombre);

int Employee_setHorasTrabajadas(Employee* this,int horasTrabajadas);
int Employee_getHorasTrabajadas(Employee* this,int* horasTrabajadas);

int Employee_setSueldo(Employee* this,int sueldo);
int Employee_getSueldo(Employee* this,int* sueldo);

int Employee_sortNombre(void* this,void* thib);
int Employee_sortId(void* thisA,void* thisB);

int getNextId(LinkedList* pArrayListEmployee);
Employee* Employee_buscarPorId(LinkedList* pArrayListEmployee,int idBuscado);
int Employee_returnIndexInLinkedList(LinkedList* this,int id);
#endif // EMPLOYEE_H_INCLUDED
