#include <stdio_ext.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Controller.h"
#include "Employee.h"

/****************************************************
    Menu:
     1. Cargar los datos de los empleados desde el archivo data.csv (modo texto).
     2. Cargar los datos de los empleados desde el archivo data.csv (modo binario).
     3. Alta de empleado
     4. Modificar datos de empleado
     5. Baja de empleado
     6. Listar empleados
     7. Ordenar empleados
     8. Guardar los datos de los empleados en el archivo data.csv (modo texto).
     9. Guardar los datos de los empleados en el archivo data.csv (modo binario).
    10. Salir
*****************************************************/
int ll_sort2(LinkedList* this, int (*pFunc)(void* ,void*), int order)
{
    int returnAux =-1;
    void* auxiliar;
    int i;
    int flagSwap;
    long contadorSeguridad = ll_len(this);

    if(this!=NULL && (order==0 || order==1) && pFunc!=NULL && ll_len(this)>0)
    {
        returnAux=0;
        do
        {
            flagSwap=0;
            for(i=0;i<(ll_len(this)-1);i++)
            {

                if(ll_get(this,i)!=NULL && ll_get(this,i+1)!=NULL)
                {
                    if(pFunc(ll_get(this,i),ll_get(this,i+1))==-1)
                    {
                        auxiliar=ll_get(this,i);
                        ll_set(this,i,ll_get(this,i+1));
                        ll_set(this,i+1,auxiliar);
                        flagSwap=1;
                    }
                }
            }
           // contadorSeguridad--;
           //printf("\n%d",contadorSeguridad);
        }while(flagSwap && contadorSeguridad);
    }
    return returnAux;

}

int main()
{
    int option = 1;
    LinkedList* listaEmpleados = ll_newLinkedList();
    do{
        printf("1. Cargar los datos de los empleados desde el archivo data.csv (modo texto).\n");
        printf("2. Cargar los datos de los empleados desde el archivo data.csv (modo binario).\n");
        printf("3. Alta de empleado\n");
        printf("4. Modificar datos de empleado\n");
        printf("5. Baja de empleado\n");
        printf("6. Listar empleados\n");
        printf("7. Ordenar empleados\n");
        printf("8. Guardar los datos de los empleados en el archivo data.csv (modo texto).\n");
        printf("9. Guardar los datos de los empleados en el archivo data.csv (modo binario).\n");
        printf("10. Salir\n");
        scanf("%d", &option);
        switch(option)
        {
            case 1:
                controller_loadFromText("data.csv",listaEmpleados);
                break;

            case 2:
                controller_loadFromBinary("data.bin",listaEmpleados);
                break;

            case 3:
                controller_addEmployee(listaEmpleados);
                break;

            case 4:
                controller_editEmployee(listaEmpleados);
                break;

            case 5:
                controller_removeEmployee(listaEmpleados);
                break;

            case 6:
                controller_ListEmployee(listaEmpleados);
                break;

            case 7:
                controller_sortEmployee(listaEmpleados);
                break;

            case 8:
                controller_saveAsText("data.csv",listaEmpleados);
                break;

            case 9:
                controller_saveAsBinary("data.bin",listaEmpleados);
                break;

            case 10:
                printf("\nSaliendo...\n");
                break;

            default:
                printf("\nOpcion invalida.\n");
        }

        __fpurge(stdin);
        printf("\nPresione una tecla para continuar.\n");
        getchar();
        system("clear");

    }while(option != 10);
    return 0;
}
