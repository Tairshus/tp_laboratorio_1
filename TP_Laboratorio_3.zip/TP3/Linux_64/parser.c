#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Employee.h"

/** \brief Parsea los datos los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int parser_EmployeeFromText(FILE* pFile , LinkedList* pArrayListEmployee)
{
    char bufferId[1024];
    char bufferNombre[1024];
    char bufferHorasTrabajadas[1024];
    char bufferSueldo[1024];
    int retorno = -1;
    int flagg = 1;
    Employee* pAux;

    if(pFile != NULL)
    {
        while(!feof(pFile))
        {
            if(flagg)
            {
                flagg = 0;
                fscanf(pFile,"%[^,],%[^,],%[^,],%[^\n]\n",
                                bufferId,
                                    bufferNombre,
                                        bufferHorasTrabajadas,
                                            bufferSueldo);
            }
                fscanf(pFile,"%[^,],%[^,],%[^,],%[^\n]\n",
                                bufferId,
                                    bufferNombre,
                                        bufferHorasTrabajadas,
                                            bufferSueldo);

                /*printf("%s - %s - %s - %s\n",
                        bufferId,
                            bufferNombre,
                                bufferHorasTrabajadas,
                                    bufferSueldo);*/

                pAux = Employee_newConParametros(bufferId,
                                        bufferNombre,
                                        bufferHorasTrabajadas,
                                        bufferSueldo);
                if(pAux != NULL)
                {
                    ll_add(pArrayListEmployee,pAux);
                }
        }
        retorno = 0;
    }


    return retorno;
}

/** \brief Parsea los datos los datos de los empleados desde el archivo data.csv (modo binario).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int parser_EmployeeFromBinary(FILE* pFile , LinkedList* pArrayListEmployee)
{
    int retorno = -1;
    int i = 1;
    Employee* pEmpleado;

    if(pFile != NULL)
    {
        retorno = 0;
        while(!feof(pFile))
        {
            pEmpleado = Employee_new();
            fread(pEmpleado,sizeof(Employee),1,pFile);
            i++;
        }
    }

    return retorno;
}
