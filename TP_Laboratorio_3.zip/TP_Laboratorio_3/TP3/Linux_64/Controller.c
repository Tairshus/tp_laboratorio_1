#include <stdio_ext.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "Employee.h"
#include "parser.h"
#include "utn.h"

int ll_sort2(LinkedList* this, int (*pFunc)(void* ,void*), int order);

/** \brief Carga los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_loadFromText(char* path , LinkedList* pArrayListEmployee)
{
    FILE* pArchivo;
    int retorno;
    pArchivo = fopen(path,"r");

    retorno = parser_EmployeeFromText(pArchivo,pArrayListEmployee);

    fclose(pArchivo);
    return retorno;
}

/** \brief Carga los datos de los empleados desde el archivo data.csv (modo binario).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_loadFromBinary(char* path , LinkedList* pArrayListEmployee)
{
    FILE* pArchivo;
    int retorno = -1;
    pArchivo = fopen(path,"rb");

    retorno = parser_EmployeeFromBinary(pArchivo,pArrayListEmployee);

    fclose(pArchivo);
    return retorno;
}

/** \brief Alta de empleados
 *
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_addEmployee(LinkedList* pArrayListEmployee)
{
    int id;
    char bufferNombre[1024];
    char bufferHorasTrabajadas[1024];
    char bufferSueldo[1024];
    int validHoras;
    int validSueldo;
    int retorno = -1;
    Employee* this;

    if(!utn_getNombre(bufferNombre,1024,"Ingrese nombre: ","Nombre invalido",2) &&
       !utn_getSoloInt(bufferHorasTrabajadas,4,"Ingrese cantidad de horas trabajadas: ","Error.",2) &&
       !utn_getSoloInt(bufferSueldo,4,"Ingrese sueldo: ","Error",2))
       {
            id = getNextId(pArrayListEmployee);
            validHoras = atoi(bufferHorasTrabajadas);
            validSueldo = atoi(bufferSueldo);
            this = Employee_new();
            Employee_setId(this,id);
            Employee_setNombre(this,bufferNombre);
            Employee_setHorasTrabajadas(this,validHoras);
            Employee_setSueldo(this,validSueldo);
            ll_add(pArrayListEmployee,this);

       }

    return retorno;
}

/** \brief Modificar datos de empleado
 *
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_editEmployee(LinkedList* pArrayListEmployee)
{
    char auxId[10];
    int id;
    int returnAux = -1;
    int opcion;
    char nombre[64];
    char horasTrabajadas[64];
    char sueldo[64];
    int validHoras;
    int validSueldo;
    Employee* empleado;

    if(pArrayListEmployee != NULL && !utn_getSoloInt(auxId,10,"Ingrese ID: ","Error",2))
    {
        id = atoi(auxId);
        empleado = Employee_buscarPorId(pArrayListEmployee,id);
        if(empleado != NULL)
        {
            printf("\nEmpleado seleccionado:\nID: %d\nNombre: %s\nHoras trabajadas: %d\nSueldo: %d\n",empleado->id,empleado->nombre,empleado->horasTrabajadas,empleado->sueldo);
            do
            {
                printf("\n1)Modificar nombre\n2)Modificar horas trabajadas\n3)Modificar sueldo\n4)Salir");
                __fpurge(stdin);
                scanf("%d",&opcion);
                switch(opcion)
                {
                    case 1:
                        if(!utn_getNombre(nombre,64,"\nIngrese nuevo nombre: ","\nError,reingrese",2))
                        {
                            Employee_setNombre(empleado,nombre);
                        }
                        else
                        {
                            printf("\nNo se pudo modificar el nombre.");
                        }
                        break;
                    case 2:
                        if(!utn_getSoloInt(horasTrabajadas,64,"\nIngrese horas trabajadas","\nError,reingrese",2))
                        {
                            validHoras = atoi(horasTrabajadas);
                            Employee_setHorasTrabajadas(empleado,validHoras);
                        }
                        else
                        {
                            printf("\nNo se pudo modificar las horas.");
                        }
                        break;
                    case 3:
                        if(!utn_getSoloInt(sueldo,64,"\nIngrese nuevo sueldo","Error,reingrese",2))
                        {
                            validSueldo = atoi(sueldo);
                            Employee_setSueldo(empleado,validSueldo);
                        }
                        else
                        {
                            printf("\nNo se pudo modificar el sueldo.");
                        }
                        break;
                    case 4:
                        printf("\nSaliendo...");
                        break;
                    default:
                        printf("Opcion invalida.");
                }
            }while(opcion != 4);
            returnAux = 0;
        }
        else
        {
            printf("\nNo se ha encontrado el empleado.");
        }
    }
    else
    {
        printf("\nNo hay una lista de empleados cargada o ha agotado el numero de intentos.\n");
    }
    return returnAux;
}

/** \brief Baja de empleado
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_removeEmployee(LinkedList* pArrayListEmployee)
{
    int returnAux = -1;
    char auxId[64];
    int id;
    Employee* empleado = NULL;
    char opcion;

     if(pArrayListEmployee != NULL && !utn_getSoloInt(auxId,10,"Ingrese ID: ","Error",2))
    {
        id = atoi(auxId);
        empleado = Employee_buscarPorId(pArrayListEmployee,id);
        if(empleado != NULL)
        {
            printf("\nEmpleado seleccionado:\nID: %d\nNombre: %s\nHoras trabajadas: %d\nSueldo: %d\n",empleado->id,empleado->nombre,empleado->horasTrabajadas,empleado->sueldo);
            printf("\nPresione S para confirmar la eliminacion.");
            opcion = getchar();
            if(opcion == 'S' || opcion == 's')
            {
                ll_remove(pArrayListEmployee,Employee_returnIndexInLinkedList(pArrayListEmployee,id));
                printf("\nEmpleado removido exitosamente.");
            }
            else
            {
                printf("\nEliminacion cancelada.\n");
            }
        }
        else
        {
            printf("\nNo se ha encontrado el empleado.");
        }
    }
    else
    {
        printf("\nNo hay una lista de empleados cargada o ha agotado el numero de intentos.\n");
    }
    return returnAux;
}

/** \brief Listar empleados
 *
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_ListEmployee(LinkedList* pArrayListEmployee)
{
    int retorno = -1;
    int i;
    void* auxEmployee;
    char nombre[64];
    int id;
    int sueldo;
    int horas;

    if(pArrayListEmployee != NULL)
    {
        retorno = 0;
        printf("\nLEN: %d\n",ll_len(pArrayListEmployee));
        for(i=0;i < ll_len(pArrayListEmployee);i++)
        {
            auxEmployee = ll_get(pArrayListEmployee,i);
            Employee_getNombre(auxEmployee,nombre);
            Employee_getId(auxEmployee,&id);
            Employee_getHorasTrabajadas(auxEmployee,&horas);
            Employee_getSueldo(auxEmployee,&sueldo);
            printf("\nID: %d",id);
            printf("\nNombre: %s",nombre);
            printf("\nHoras Trabajadas: %d",horas);
            printf("\nSueldo: %d",sueldo);
        }
    }
    else
    {
        printf("\nNo hay una lista de empleados cargada.\n");
    }

    return retorno;
}

/** \brief Ordenar empleados
 *
 * \param pArrayListEmployee LinkedList*
 * \return int = -1 si el puntero a la LinkedList es NULL / int = 0 si no hubo problema
 *
 */
int controller_sortEmployee(LinkedList* pArrayListEmployee)
{
    int returnAux = -1;

    if(pArrayListEmployee != NULL)
    {
        ll_sort2(pArrayListEmployee,Employee_sortNombre,0);
        returnAux = 0;
    }
    else
    {
        printf("\nNo hay una lista de empleados cargada.\n");
    }

    return returnAux;
}

/** \brief Guarda los datos de los empleados en el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return -1 si el puntero a la LinkedList es NULL o el puntero a FILE es NULL
 *
 */
int controller_saveAsText(char* path , LinkedList* pArrayListEmployee)
{
    int returnAux = -1;
    FILE* pFile=fopen(path,"w");
    Employee* pEmployee;
    int auxId;
    int auxSueldo;
    int auxHorasTrabajadas;
    char nombre[1024];
    int i;

    if(pFile!=NULL && pArrayListEmployee !=NULL)
    {
        fprintf(pFile,"Id,Nombre,HorasTrabajadas,Sueldo\n");
        for(i=0;i<ll_len(pArrayListEmployee);i++)
        {
            pEmployee=ll_get(pArrayListEmployee,i);
            Employee_getId(pEmployee,&auxId);
            Employee_getNombre(pEmployee,nombre);
            Employee_getSueldo(pEmployee,&auxSueldo);
            Employee_getHorasTrabajadas(pEmployee,&auxHorasTrabajadas);
            fprintf(pFile,"%d,%s,%d,%d\n",auxId,nombre,auxHorasTrabajadas,auxSueldo);
        }
        returnAux = 0;
    }
    else
    {
        printf("\nNo hay una lista de empleados cargada.\n");
    }
    fclose(pFile);

    return returnAux;
}

/** \brief Guarda los datos de los empleados en el archivo data.csv (modo binario).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return -1 si el puntero a la LinkedList es NULL / 0 si no hubo problema
 *
 */
int controller_saveAsBinary(char* path , LinkedList* pArrayListEmployee)
{
    FILE* pArchivo = fopen(path,"wb");
    Employee* pEmpleado;
    int i;
    int returnAux = -1;

    if(pArchivo != NULL && pArrayListEmployee != NULL)
    {
        for(i=0;i<ll_len(pArrayListEmployee);i++)
        {
            pEmpleado = ll_get(pArrayListEmployee,i);
            fwrite(pEmpleado,sizeof(Employee),1,pArchivo);
        }
        returnAux = 0;
    }
    else
    {
        printf("\nNo hay una lista de empleados cargada.\n");
    }

    fclose(pArchivo);

    return returnAux;
}

/** \brief Ordena los elementos de la lista utilizando la funcion criterio recibida como parametro
 * \param pList LinkedList* Puntero a la lista
 * \param pFunc (*pFunc) Puntero a la funcion criterio
 * \param order int  [1] Indica orden ascendente - [0] Indica orden descendente
 * \return int Retorna  (-1) Error: si el puntero a la listas es NULL
                                ( 0) Si ok
 */
int ll_sort2(LinkedList* this, int (*pFunc)(void* ,void*), int order)
{
    int returnAux =-1;
    int i;
    int j;
    void* aux;
    void* pElement1;
    void* pElement2;
    int len = ll_len(this);

    if(this != NULL && (order == 0 || order == 1) && pFunc != NULL && len > 0)
    {
        returnAux = 0;
        for(i=0;i<len-1;i++)
        {
            for(j=i+1;j<len;j++)
            {
                pElement1 = ll_get(this,i);
                pElement2 = ll_get(this,j);
                if(pFunc(pElement1,pElement2) == -1)
                {
                    if(order == 0)
                    {
                        aux = pElement1;
                        ll_set(this,i,pElement2);
                        ll_set(this,j,aux);
                    }
                }
            }
        }
    }
    return returnAux;
}
