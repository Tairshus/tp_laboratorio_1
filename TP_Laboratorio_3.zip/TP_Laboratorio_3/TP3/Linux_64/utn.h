#ifndef UTN_H_INCLUDED
#define UTN_H_INCLUDED

int utn_getNombre(  char* pNombre, int limite, char* msg,
                    char* msgErr, int reintentos);

int isValidNombre(char* pBuffer,int limite);

int isValidFloat(char* pBuffer,int limite);

int isValidInt(char* pBuffer,int limite);

int utn_getSoloFloat(  char* pFloat, int limite, char* msg,
                    char* msgErr, int reintentos);

int utn_getSoloInt(  char* pInt, int limite, char* msg,
                    char* msgErr, int reintentos);

int utn_getLetrasYNumeros(char* pBuffer,int limite,char* msj);

void utn_toLowerWord(char* pBuffer);
#endif // UTN_H_INCLUDED

